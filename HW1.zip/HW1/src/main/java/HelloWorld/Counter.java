package HelloWorld;
public class Counter {



    public int checkLength(String name) {
        System.out.println("töötab!");
        return name.length();
    }
}