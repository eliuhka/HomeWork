package HelloWorld;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class GreeterTest {



    private Greeter greeter = new Greeter();

    String  name = "Erki";
    int nameLength = 4;
    String surname = "Liuhka";
    int surnameLength = 6;



    @Test
    public void greeterSaysHello() {
        assertThat(greeter.Hello(name), containsString("Hello, " + name + ", Your name is " + nameLength + " letters long!"));
        assertThat(greeter.HelloTwo(surname), containsString("Hello, " + surname + ", Your surname is " + surnameLength + " letters long!"));
    }



}
