package HelloWorld;
import static org.junit.Assert.*;
import org.junit.Test;
public class CounterTest {



    @Test
    public void checkLength() {
        Counter count = new Counter();
        String firstName = "Erki";
        int expectedResult = 4;

        assertEquals(expectedResult, count.checkLength(firstName));
    }
}