package HelloWorld;
public class Greeter extends Counter {



    public String Hello() {
        String result = "Hello World!";
        return result;
    }




    public String Hello(String name) {
        Counter count = new Counter();

        if (count.checkLength(name) < 4 || count.checkLength(name) > 10)
            return "Wrong! Your name has less then four letters";
        String length = "Hello, " + name + ", Your name is " + count.checkLength(name) + " letters long!";
        return length;

    }




    public String HelloTwo(String surname) {
        Counter count = new Counter();

        if (count.checkLength(surname) < 4 || count.checkLength(surname) > 10)
            return "Wrong! Your surname has less than four letters!";
        String length2 = "Hello, " + surname + ", Your surname is " + count.checkLength(surname) + " letters long!";
        return length2;
    }



}
